package ControlStructures;

public class SwitchStatement {
    public static void main(String[] args) {
        // Using switch with integer
        int num = 3;
        switch (num) {
            case 1:
                System.out.println("One");
                break;
            case 2:
                System.out.println("Two");
                break;
            case 3:
                System.out.println("Three");
                break;
            default:
                System.out.println("Other number");
                
        }

        // Using switch with string
        String day = "surya";
        switch (day) {
            case "Monday":
                System.out.println("Start of the work week");
                break;
            case "Tuesday":
                System.out.println("Second day of the work week");
                break;
            case "Wednesday":
                System.out.println("Midweek");
                break;
            default:
                System.out.println("Other day");
                break;
        }
    }
}

