package ControlStructures;

public class IfElseStatement {
    public static void main(String[] args) {
        int a = 10, b = 20;

        if (a > b) {
            System.out.println("a is less than b");
        }
        else if(a==10) {
        	System.out.println("a==10");
        }
        else {
            System.out.println("a is not less than b");
        }
    }
}

