package ControlStructures;

public class NestedIfElse {
    public static void main(String[] args) {
        int a = 10, b = 20, c = 30;

        if (a < b) {
            if (b > c) {
                System.out.println("a is less than b and b is less than c");
            } else {
                System.out.println("a is less than b but b is not less than c");
            }
            System.out.println("aa");
        } else {
            System.out.println("a is not less than b");
            if (b < c) {
                System.out.println("a is less than b and b is less than c");
            } else {
                System.out.println("a is less than b but b is not less than c");
            }
        }
    }
}

