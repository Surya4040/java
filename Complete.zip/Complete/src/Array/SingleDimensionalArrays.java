package Array;

public class SingleDimensionalArrays {
    public static void main(String[] args) {
        int[] array = {61, 6, 88, 55, 85};
        System.out.println(array[2]);

        System.out.println("Single-Dimensional Arrays:");
        for (int i = 0; i < array.length; i++) {
            System.out.println("array[" + i + "] = " + array[i]);
        }
    }
}

