package Packagemodule;

import Oops.Packages.Util;

public class MainApp {
 public static void main(String[] args) {
     Util.printMessage("Hello from MainApp!");
 }
}
