package Packagemodule;

public class Helper {
 public void greet() {
     System.out.println("Hello from Helper!");
 }
}
