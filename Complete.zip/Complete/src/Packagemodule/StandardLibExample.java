package Packagemodule;

//StandardLibExample.java
import java.util.ArrayList;
import java.util.List;

public class StandardLibExample {
 public static void main(String[] args) {
     List<String> list = new ArrayList<>();
     list.add("Hello");
     list.add("World");
     System.out.println(list);
 }
}

