package Packagemodule;
public class Main {
    public static void main(String[] args) {
        Helper helper = new Helper();
        helper.greet();
    }
}
