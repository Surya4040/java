package Collections;

//MapExample.java
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapExample {
 public static void main(String[] args) {
     // Using HashMap
     Map<String, Integer> hashMap = new HashMap<>();
     hashMap.put("One", 1);
     hashMap.put("Two", 2);
     hashMap.put("Three", 3);
     System.out.println("HashMap: " + hashMap);

     // Using LinkedHashMap
     Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
     linkedHashMap.put("A", 1);
     linkedHashMap.put("B", 2);
     linkedHashMap.put("C", 3);
     System.out.println("LinkedHashMap: " + linkedHashMap);

     // Using TreeMap
     Map<String, Integer> treeMap = new TreeMap<>();
     treeMap.put("Zebra", 1);
     treeMap.put("Monkey", 2);
     treeMap.put("Lion", 3);
     System.out.println("TreeMap: " + treeMap);
 }
}

