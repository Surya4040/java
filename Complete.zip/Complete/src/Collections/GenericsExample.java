package Collections;

//GenericsExample.java
import java.util.ArrayList;
import java.util.List;

public class GenericsExample {
 public static void main(String[] args) {
     // Using generics with List
     List<String> stringList = new ArrayList<>();
     stringList.add("One");
     stringList.add("Two");
     stringList.add("Three");

     for (String item : stringList) {
         System.out.println("String list item: " + item);
     }

     // Using generics with custom class
     List<Box<Integer>> integerBoxList = new ArrayList<>();
     integerBoxList.add(new Box<>(1));
     integerBoxList.add(new Box<>(2));
     integerBoxList.add(new Box<>(3));

     for (Box<Integer> box : integerBoxList) {
         System.out.println("Box value: " + box.getValue());
     }
 }
}

class Box<T> {
 private T value;

 public Box(T value) {
     this.value = value;
 }

 public T getValue() {
     return value;
 }

 public void setValue(T value) {
     this.value = value;
 }
}
