package Collections;

//IteratorExample.java
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class IteratorExample {
 public static void main(String[] args) {
     List<String> list = new ArrayList<>();
     list.add("One");
     list.add("Two");
     list.add("Three");

     // Using Iterator
     Iterator<String> iterator = list.iterator();
     while (iterator.hasNext()) {
         System.out.println("Iterator value: " + iterator.next());
     }

     // Using enhanced for-loop (Iterable interface)
     for (String item : list) {
         System.out.println("Enhanced for-loop value: " + item);
     }
 }
}
