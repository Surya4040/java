package Collections;

//QueueDequeExample.java
import java.util.ArrayDeque;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Deque;

public class QueueDequeExample {
 public static void main(String[] args) {
     // Using Queue
     Queue<String> queue = new LinkedList<>();
     queue.add("First");
     queue.add("Second");
     queue.add("Third");
     System.out.println("Queue: " + queue);
     System.out.println("Removed from Queue: " + queue.poll());

     // Using Deque
     Deque<String> deque = new ArrayDeque<>();
     deque.addFirst("One");
     deque.addLast("Two");
     deque.addFirst("Three");
     System.out.println("Deque: " + deque);
     System.out.println("Removed from Deque: " + deque.removeFirst());
 }
}

