package Collections;
//ConcurrentCollectionsExample.java
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ConcurrentCollectionsExample {
 public static void main(String[] args) throws InterruptedException {
     // Using ConcurrentHashMap
     ConcurrentHashMap<String, Integer> concurrentMap = new ConcurrentHashMap<>();
     concurrentMap.put("A", 1);
     concurrentMap.put("B", 2);
     concurrentMap.put("C", 3);

     // Using ConcurrentLinkedQueue
     ConcurrentLinkedQueue<String> concurrentQueue = new ConcurrentLinkedQueue<>();
     concurrentQueue.add("One");
     concurrentQueue.add("Two");
     concurrentQueue.add("Three");

     // Multithreading example
     ExecutorService executor = Executors.newFixedThreadPool(2);
     executor.submit(() -> {
         concurrentMap.put("D", 4);
         concurrentQueue.add("Four");
     });
     executor.submit(() -> {
         System.out.println("ConcurrentMap: " + concurrentMap);
         System.out.println("ConcurrentQueue: " + concurrentQueue);
     });

     executor.shutdown();
     executor.awaitTermination(1, TimeUnit.MINUTES);
 }
}

