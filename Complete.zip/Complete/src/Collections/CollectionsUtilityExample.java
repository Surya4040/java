package Collections;

//CollectionsUtilityExample.java
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CollectionsUtilityExample {
 public static void main(String[] args) {
     List<String> list = new ArrayList<>();
     list.add("Banana");
     list.add("Apple");
     list.add("Cherry");

     // Sorting the list
     Collections.sort(list);
     System.out.println("Sorted list: " + list);

     // Shuffling the list
     Collections.shuffle(list);
     System.out.println("Shuffled list: " + list);

     // Finding the max element
     String max = Collections.max(list);
     System.out.println("Max element: " + max);
 }
}

