package Collections;

//SetExample.java
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetExample {
 public static void main(String[] args) {
     // Using HashSet
     Set<String> hashSet = new HashSet<>();
     hashSet.add("Apple");
     hashSet.add("Banana");
     hashSet.add("Cherry");
     System.out.println("HashSet: " + hashSet);

     // Using LinkedHashSet
     Set<String> linkedHashSet = new LinkedHashSet<>();
     linkedHashSet.add("One");
     linkedHashSet.add("Two");
     linkedHashSet.add("Three");
     System.out.println("LinkedHashSet: " + linkedHashSet);

     // Using TreeSet
     Set<String> treeSet = new TreeSet<>();
     treeSet.add("Dog");
     treeSet.add("Cat");
     treeSet.add("Bird");
     System.out.println("TreeSet: " + treeSet);
 }
}

