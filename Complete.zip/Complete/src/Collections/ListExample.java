package Collections;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ListExample {
 public static void main(String[] args) {
     // Using ArrayList
     List<String> arrayList = new ArrayList<>();
     arrayList.add("One");
     arrayList.add("Two");
     arrayList.add("Three");
     System.out.println("ArrayList: " + arrayList);

     // Using LinkedList
     List<String> linkedList = new LinkedList<>();
     linkedList.add("A");
     linkedList.add("B");
     linkedList.add("C");
     System.out.println("LinkedList: " + linkedList);
 }
}

