package ExceptionHandling;

public class AutoCloseableExample {
    static class MyResource implements AutoCloseable {
        @Override
        public void close() {
            System.out.println("Resource closed.");
        }

        void use() {
            System.out.println("Resource used.");
        }
    }

    public static void main(String[] args) {
        try (MyResource resource = new MyResource()) {
            resource.use();
        }
    }
}
