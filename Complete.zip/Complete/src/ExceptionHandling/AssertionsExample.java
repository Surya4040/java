package ExceptionHandling;

public class AssertionsExample {
    public static void main(String[] args) {
        int number = -5;
        assert number >= 0 : "Number should be non-negative.";
        System.out.println("Number: " + number);
    }
}

