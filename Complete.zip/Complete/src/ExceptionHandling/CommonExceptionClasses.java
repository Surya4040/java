package ExceptionHandling;

public class CommonExceptionClasses {
    public static void main(String[] args) {
        try {
            // ArrayIndexOutOfBoundsException
            int[] arr = new int[5];
            int value = arr[10];

            // NullPointerException
            String str = null;
            str.length();

            // NumberFormatException
            int num = Integer.parseInt("abc");

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBoundsException caught: " + e.getMessage());
        } catch (NullPointerException e) {
            System.out.println("NullPointerException caught: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("NumberFormatException caught: " + e.getMessage());
        }
    }
}

