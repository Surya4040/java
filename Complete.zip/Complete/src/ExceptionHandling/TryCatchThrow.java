package ExceptionHandling;

public class TryCatchThrow {
    public static void main(String[] args) {
        int result1 = divide(10, 0);
        try {
            int result = divide(10, 0);
            System.out.println("Result: " + result);
        } catch (Exception e) {
            System.out.println("Exception caught: " + e);
        }
        System.out.println("Exception is working");
    }

    static int divide(int a, int b) {
        if (b == 0) {
            throw new ArithmeticException("Cannot divide by zero.");
        }
        return a / b;
    }
}

