package IO;

import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.Formatter;
import java.util.Scanner;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

// A class demonstrating various Java I/O operations
public class JavaIOExamples {

    public static void main(String[] args) {
        basicIOExample();
        byteStreamsExample();
        characterStreamsExample();
        bufferedReaderWriterExample();
        serializationExample();
        randomAccessFileExample();
        scannerFormatterExample();
        nioExample();
        pathFilesExample();
        watchDirectoryExample();
        zipFileExample();
    }

    // Introduction to Java I/O
    public static void basicIOExample() {
        String filePath = "example.txt";
        String content = "Hello, world!";

        // Write to a file
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write(content);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Read from a file
        try (FileReader reader = new FileReader(filePath)) {
            int character;
            while ((character = reader.read()) != -1) {
                System.out.print((char) character);
            }
            System.out.println();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Byte Streams
    public static void byteStreamsExample() {
        String inputFile = "input.txt";
        String outputFile = "output.txt";

        try (FileInputStream inputStream = new FileInputStream(inputFile);
             FileOutputStream outputStream = new FileOutputStream(outputFile)) {

            int byteData;
            while ((byteData = inputStream.read()) != -1) {
                outputStream.write(byteData);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Character Streams
    public static void characterStreamsExample() {
        String inputFile = "input.txt";
        String outputFile = "output.txt";

        try (FileReader reader = new FileReader(inputFile);
             FileWriter writer = new FileWriter(outputFile)) {

            int charData;
            while ((charData = reader.read()) != -1) {
                writer.write(charData);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // BufferedReader and BufferedWriter
    public static void bufferedReaderWriterExample() {
        String inputFile = "input.txt";
        String outputFile = "output.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {

            String line;
            while ((line = reader.readLine()) != null) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Object Serialization
    public static void serializationExample() {
        String filePath = "object.ser";
        Person person = new Person("John", 30);

        // Serialize object
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filePath))) {
            out.writeObject(person);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Deserialize object
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filePath))) {
            Person deserializedPerson = (Person) in.readObject();
            System.out.println("Deserialized Person: " + deserializedPerson);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    static class Person implements Serializable {
        private static final long serialVersionUID = 1L;
        private String name;
        private int age;

        public Person(String name, int age) {
            this.name = name;
            this.age = age;
        }

        @Override
        public String toString() {
            return "Person{name='" + name + "', age=" + age + "}";
        }
    }

    // RandomAccessFile
    public static void randomAccessFileExample() {
        String filePath = "random.txt";

        try (RandomAccessFile file = new RandomAccessFile(filePath, "rw")) {
            // Write to file
            file.writeUTF("Hello, world!");
            file.writeInt(42);

            // Move file pointer to the beginning
            file.seek(0);

            // Read from file
            String message = file.readUTF();
            int number = file.readInt();

            System.out.println("Read from file: " + message + " " + number);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Scanner and Formatter
    public static void scannerFormatterExample() {
        String input = "Hello 123";

        // Using Scanner
        Scanner scanner = new Scanner(input);
        String word = scanner.next();
        int number = scanner.nextInt();
        System.out.println("Word: " + word + ", Number: " + number);

        // Using Formatter
        try (Formatter formatter = new Formatter()) {
            formatter.format("Word: %s, Number: %d", word, number);
            System.out.println(formatter);
        }
    }

    // NIO (New I/O) API
    public static void nioExample() {
        Path filePath = Paths.get("nio_example.txt");
        String content = "Hello, NIO!";

        try {
            // Write to file
            Files.write(filePath, content.getBytes());

            // Read from file
            String fileContent = Files.readString(filePath);
            System.out.println("File content: " + fileContent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Path and Files
    public static void pathFilesExample() {
        Path filePath = Paths.get("path_files_example.txt");
        String content = "Hello, Path and Files!";

        try {
            // Create file and write to it
            Files.write(filePath, content.getBytes());

            // Read from file
            String fileContent = Files.readString(filePath);
            System.out.println("File content: " + fileContent);

            // Delete file
            Files.delete(filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Filtering and Watching Directories (Java 7 and later)
    public static void watchDirectoryExample() {
        Path dir = Paths.get(".");

        try (WatchService watchService = FileSystems.getDefault().newWatchService()) {
            dir.register(watchService, StandardWatchEventKinds.ENTRY_CREATE,
                         StandardWatchEventKinds.ENTRY_DELETE,
                         StandardWatchEventKinds.ENTRY_MODIFY);

            WatchKey key;
            while ((key = watchService.take()) != null) {
                for (WatchEvent<?> event : key.pollEvents()) {
                    WatchEvent.Kind<?> kind = event.kind();
                    Path filePath = (Path) event.context();
                    System.out.println(kind + ": " + filePath);
                }
                key.reset();
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Zip File Handling
    public static void zipFileExample() {
        String sourceFile = "zipfile_example.txt";
        String zipFileName = "example.zip";

        // Create a file to be zipped
        try {
            Files.write(Paths.get(sourceFile), "Hello, Zip!".getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Zip the file
        try (FileOutputStream fos = new FileOutputStream(zipFileName);
             ZipOutputStream zos = new ZipOutputStream(fos)) {

            ZipEntry zipEntry = new ZipEntry(sourceFile);
            zos.putNextEntry(zipEntry);
            byte[] bytes = Files.readAllBytes(Paths.get(sourceFile));
            zos.write(bytes, 0, bytes.length);
            zos.closeEntry();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Unzip the file
        try (FileInputStream fis = new FileInputStream(zipFileName);
             ZipInputStream zis = new ZipInputStream(fis)) {

            ZipEntry zipEntry = zis.getNextEntry();
            while (zipEntry != null) {
                String fileName = zipEntry.getName();
                Path outputPath = Paths.get("unzipped_" + fileName);
                Files.copy(zis, outputPath, StandardCopyOption.REPLACE_EXISTING);
                zipEntry = zis.getNextEntry();
            }
            zis.closeEntry();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

