package IterationControlStructures;

public class WhileLoop {
    public static void main(String[] args) {
        int i = 0;
        System.out.println("While Loop:");
        while (i != 5) {
        	 i++;
            System.out.println("i = " + i);
           
        }
    }
}

