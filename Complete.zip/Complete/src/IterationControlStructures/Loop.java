package IterationControlStructures;

public class Loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
for(int a=0; a<10;++a) {
	System.out.println("a "+a);
}
	}

}
