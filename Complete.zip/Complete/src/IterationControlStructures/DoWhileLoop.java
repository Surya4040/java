package IterationControlStructures;

public class DoWhileLoop {
    public static void main(String[] args) {
        int i = 0;

        System.out.println("Do-While Loop:");
        do {
            System.out.println("i = " + "surya");
            i++;
        } while (i > 5);
    }
}

