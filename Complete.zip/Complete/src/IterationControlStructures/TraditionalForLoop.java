package IterationControlStructures;

public class TraditionalForLoop {
    public static void main(String[] args) {
        System.out.println("Traditional For Loop:");
        for (int i = 0; i < 5; ++i) {
            System.out.println("i = " + i);
        }
    }
}

