package String;

public class StringInterning {
    public static void main(String[] args) {
        String str1 = new String("Hello");
        String str2 = "Hello";
        String str3 = str1.intern();

        System.out.println("String Interning:");
        System.out.println("str1 == str2: " + (str1 == str2));
        System.out.println("str2 == str3: " + (str2 == str3));
    }
}

