package String;

public class StringManipulation {
    public static void main(String[] args) {
        String str1 = "Hello";
        String str2 = "World";
        
        // String concatenation
        String str3 = str1 + ", " + str2 + "!";
        System.out.println("Concatenated String: " + str3);
        
        // String equality
        String str4 = "Hello";
        System.out.println("str1 equals str4: " + str1.equals(str4));
    }
}

