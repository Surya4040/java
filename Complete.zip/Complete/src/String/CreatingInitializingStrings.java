package String;

public class CreatingInitializingStrings {
    public static void main(String[] args) {
        String str1 = "Hello, World!";
        String str2 = new String("Java Programming");

        System.out.println("Creating and Initializing Strings:");
        System.out.println("str1: " + str1);
        System.out.println("str2: " + str2);
    }
}

