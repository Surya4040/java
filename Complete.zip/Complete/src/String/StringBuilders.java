package String;

public class StringBuilders {
	    public static void main(String[] args) {
	        StringBuilder sb = new StringBuilder("Hello");

	        // Using StringBuilder methods
	        sb.append(", ");
	        sb.append("World!");
	        sb.insert(0, "Java ");
	        sb.replace(5, 6, "-");
	        sb.delete(5, 6);

	        System.out.println("StringBuilder: " + sb.toString());
	    }
	}

