package String;

public class StringBuffers {
	    public static void main(String[] args) {
	        StringBuffer sb = new StringBuffer("Hello");

	        // Using StringBuffer methods
	        sb.append(", ");
	        sb.append("World!");
	        sb.insert(0, "Java ");
	        sb.replace(5, 6, "-");
	        sb.delete(5, 6);

	        System.out.println("StringBuffer: " + sb.toString());
	    }
	}

