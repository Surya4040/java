package String;

public class StringConversion {
    public static void main(String[] args) {
        int number = 123;
        double decimal = 45.67;

        // Converting numbers to strings
        String strNumber = Integer.toString(number);
        String strDecimal = Double.toString(decimal);

        // Converting strings to numbers
        int parsedNumber = Integer.parseInt(strNumber);
        double parsedDecimal = Double.parseDouble(strDecimal);

        System.out.println("String Conversion:");
        System.out.println("strNumber: " + strNumber);
        System.out.println("strDecimal: " + strDecimal);
        System.out.println("parsedNumber: " + parsedNumber);
        System.out.println("parsedDecimal: " + parsedDecimal);
    }
}

