package Basic;
import java.util.Arrays;

public class DataTypes {

 public static void main(String[] args) {
     byte byteVar = 127;      
     short shortVar = 32000;  
     int intVar =1000009766;    
     long longVar = 100000L;  

     // Floating-Point Types
     float floatVar = 10.5f;   
     double doubleVar = 20.5;  

     // Character Type
     char charVar = 'A';       

     // Boolean Type
     boolean booleanVar = true; 
     
     System.out.println("Primitive Data Types:");
     System.out.println("byteVar: " + byteVar);
     System.out.println("shortVar: " + shortVar);
     System.out.println("intVar: " + intVar);
     System.out.println("longVar: " + longVar);
     System.out.println("floatVar: " + floatVar);
     System.out.println("doubleVar: " + doubleVar);
     System.out.println("charVar: " + charVar);
     System.out.println("booleanVar: " + booleanVar);
     
     // Non-Primitive Data Types

     // Strings
     String stringVar = "Hello, World!";
     System.out.println("stringVar: " + stringVar);

     // Arrays
     int[] arrayVar = {1, 2, 3, 4, 5};
     System.out.println("arrayVar: " + Arrays.toString(arrayVar));

     // Classes and Objects
     Person personVar = new Person("John", 25);
     System.out.println("personVar: " + personVar);

     // Type Conversion and Casting

     // Implicit Casting (smaller to larger type)
     int intToDouble = 100;
     double doubleVar2 = intToDouble;
     System.out.println("Implicit Casting (int to double): " + doubleVar2);

     // Explicit Casting (larger to smaller type)
     double doubleToInt = 100.99;
     int intVar2 = (int) doubleToInt;
     System.out.println("Explicit Casting (double to int): " + intVar2);
 }
}

class Person {
 String name;
 int age;

 // Constructor
 Person(String name, int age) {
     this.name = name;
     this.age = age;
 }

 @Override
 public String toString() {
     return "Person[name=" + name + ", age=" + age + "]";
 }
}
