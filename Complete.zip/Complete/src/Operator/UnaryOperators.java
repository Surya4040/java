package Operator;

public class UnaryOperators {
    public static void main(String[] args) {
        int a = 10;

        System.out.println("Unary Operators:");
        System.out.println("Initial Value: " + a);

        // Increment
        System.out.println("After Increment: " + (++a));
        // Decrement
        System.out.println("After Decrement: " + (a--));
        System.out.println("After Decrement: " + (a));
    }
}
