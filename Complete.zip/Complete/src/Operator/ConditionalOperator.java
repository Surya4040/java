package Operator;

public class ConditionalOperator {
    public static void main(String[] args) {
        int a = 10, b = 20;

        System.out.println("Conditional (Ternary) Operator:");
        String result = (a > b) ? "a is greater than b" : "a is not greater than b";
        System.out.println(result);
    }
}

