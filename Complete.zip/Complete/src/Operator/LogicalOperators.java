package Operator;

public class LogicalOperators {
    public static void main(String[] args) {
        int x =10 , y = 20;
        System.out.println("Logical Operators:");
        System.out.println("x && y: " + !(x==y && y==x));
        System.out.println("x || y: " + (x<y || y>10));
        System.out.println("!x: " + (!(y==10)));
    }
}

