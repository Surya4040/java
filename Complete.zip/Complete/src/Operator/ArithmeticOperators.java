package Operator;

public class ArithmeticOperators {
    public static void main(String[] args) {
        float a = (float) 10.0, b = (float) 5.8;
        System.out.println("Arithmetic Operators:");
        System.out.println("Addition: " + (a + b));
        System.out.println("Subtraction: " + (a - b));
        System.out.println("Multiplication: " + (a * b));
        System.out.println("Division: " + (a / b));
        System.out.println("Modulus: " + (a % b));
    }
}

