package Operator;

public class InstanceofOperator {
    public static void main(String[] args) {
        String str = "Hello, World!";
        System.out.println("Instanceof Operator:");
        System.out.println("Is str an instance of String? " + (str instanceof String));
    }
}

