package Operator;

public class MiscOperators {
    public static void main(String[] args) {
        // Using instanceof and conditional operator
        String str = "Hello";
        System.out.println("Miscellaneous Operators:");
        System.out.println("Is str an instance of String? " + (str instanceof String));
        
        int a = 10, b = 20;
        String result = (a > b) ? "a is greater than b" : "a is not greater than b";
        System.out.println(result);
    }
}

