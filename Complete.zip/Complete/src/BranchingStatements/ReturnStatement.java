package BranchingStatements;

public class ReturnStatement {
    public static void main(String[] args) {
        System.out.println("Return Statement:");
        System.out.println("Result of addition: " + addNumbers(5, 3));
        int meth=addNumbers(5,7);
        System.out.println("meth"+meth);
    }

    public static int addNumbers(int a, int b) {
        return a + b; // Return the sum of a and b
    }
}

