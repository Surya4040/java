package BranchingStatements;

public class ContinueStatement {
    public static void main(String[] args) {
        System.out.println("Continue Statement:");
        for (int i = 0; i < 5; i++) {
            if (i == 3) {
                continue; // Skip the current iteration when i equals 3
            }
            System.out.println("i = " + i);
        }
        System.out.println("Loop completed.");
    }
}

