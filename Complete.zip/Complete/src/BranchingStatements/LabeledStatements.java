package BranchingStatements;

public class LabeledStatements {
    public static void main(String[] args) {
        System.out.println("Labeled Statements:");
        outerLoop:
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (i == 1 && j == 1) {
                    continue outerLoop; // Break the outer loop when i and j both equal 1
                }
                System.out.println("i = " + i + ", j = " + j);
            }
        }
        System.out.println("Loop exited.");
    }
}

