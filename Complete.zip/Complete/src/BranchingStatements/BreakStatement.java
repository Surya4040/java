package BranchingStatements;

public class BreakStatement {
    public static void main(String[] args) {
        System.out.println("Break Statement:");
        for (int i = 0; i < 5; i++) {
            if (i == 3) {
                break; // Exit the loop when i equals 3
            }
            System.out.println("i = " + i);
        }
        System.out.println("Loop exited.");
    }
}
