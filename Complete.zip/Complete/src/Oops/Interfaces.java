package Oops;

public class Interfaces {
    // Interface definition
    interface Animal {
        void sound();
        void eat();
    }

    // Implementing the interface
    static class Dog implements Animal {
        @Override
        public void sound() {
            System.out.println("The dog barks.");
        }

        @Override
        public void eat() {
            System.out.println("The dog eats.");
        }
    }

    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.sound();
        dog.eat();
    }
}
