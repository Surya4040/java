package Oops;

public class Constructors {
   

    public static void main(String[] args) {
        // Creating an object using the constructor
        Person2 person = new Person2("Bob", 25);
        person.display();
    }
}
 class Person2 {
    String name;
    int age;

    // Constructor
    Person2(String name, int age) {
        this.name = name;
        this.age = age;
    }

    void display() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}