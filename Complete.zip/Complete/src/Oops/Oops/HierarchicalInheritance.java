package Oops.Oops;


    // Base class
     class Animalss {
        void eat() {
            System.out.println("This animal eats food.");
        }
    }

    // Derived class 1
     class Dogss extends Animalss {
        void bark() {
            System.out.println("The dog barks.");
        }
    }

    // Derived class 2
     class Cat extends Animalss {
        void meow() {
            System.out.println("The cat meows.");
        }
    }
    public class HierarchicalInheritance {
    public static void main(String[] args) {
        Dogss dog = new Dogss();
        Cat cat = new Cat();

        dog.eat(); // Method from base class
        dog.bark(); // Method from derived class Dog

        cat.eat(); // Method from base class
        cat.meow(); // Method from derived class Cat
    }
}

