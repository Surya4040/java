package Oops.Oops;

public class HybridInheritance {
    // Base class
    static class Animal {
        void eat() {
            System.out.println("This animal eats food.");
        }
    }

    // Derived class 1
    static class Mammal extends Animal {
        void walk() {
            System.out.println("This mammal walks.");
        }
    }

    // Derived class 2
    static class Bird extends Animal {
        void fly() {
            System.out.println("This bird flies.");
        }
    }

    // Interface
    interface Pet {
        void beFriendly();
    }

    // Class implementing hybrid inheritance
    static class Dog extends Mammal implements Pet {
        void bark() {
            System.out.println("The dog barks.");
        }

        @Override
        public void beFriendly() {
            System.out.println("The dog is friendly.");
        }
    }

    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.eat(); // Method from Animal class
        dog.walk(); // Method from Mammal class
        dog.bark(); // Method from Dog class
        dog.beFriendly(); // Method from Pet interface
       Bird bird =new Bird();
       bird.fly();
    }
}

