package Oops.Oops;


    // Base class
     class Animals {
        void eat() {
            System.out.println("This animal eats food.");
        }
    }

    // Intermediate class
     class Mammal extends Animals {
        void walk() {
            System.out.println("This mammal walks.");
        }
    }

    // Derived class
     class Dogs extends Mammal {
        void bark() {
            System.out.println("The dog barks.");
        }
    }
    public class MultilevelInheritance {
    public static void main(String[] args) {
        Dogs dog = new Dogs();
        dog.eat(); // Method from base class
        dog.walk(); // Method from intermediate class
        dog.bark(); // Method from derived class
    }
}

