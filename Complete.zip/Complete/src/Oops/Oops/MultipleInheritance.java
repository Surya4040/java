package Oops.Oops;


    // Interface 1
    interface Animal1 {
        void eat();
    }

    // Interface 2
    interface Mammal1 {
        void walk();
    }

    // Class implementing multiple interfaces
     class Dog2 implements Animal1, Mammal1 {
        @Override
        public void eat() {
            System.out.println("The dog eats.");
        }

        @Override
        public void walk() {
            System.out.println("The dog walks.");
        }

        void bark() {
            System.out.println("The dog barks.");
        }
    }
    public class MultipleInheritance {
    public static void main(String[] args) {
        Dog2 dog = new Dog2();
        dog.eat(); // Method from Animal interface
        dog.walk(); // Method from Mammal interface
        dog.bark(); // Method from Dog class
        
    }
}

