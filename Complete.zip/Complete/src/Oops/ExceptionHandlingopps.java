package Oops;

public class ExceptionHandlingopps {
	    static class DivideByZeroException extends Exception {
	        DivideByZeroException(String message) {
	            super(message);
	        }
	    }

	    static class Calculator {
	        int divide(int a, int b) throws DivideByZeroException {
	            if (b == 0) {
	                throw new DivideByZeroException("Cannot divide by zero.");
	            }
	            return a / b;
	        }
	    }

	    public static void main(String[] args) {
	        Calculator calculator = new Calculator();
	        try {
	            System.out.println("Result: " + calculator.divide(10, 0));
	        } catch (DivideByZeroException e) {
	            System.out.println("Exception: " + e.getMessage());
	        }
	    }
	}

