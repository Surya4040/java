package Oops;

public class ClassesAndObjects {
    // Class definition
    public static void main(String[] args) {
        // Creating an object
        Person person = new Person();
        person.name = "Alice";
        person.age = 30;
        person.display();
        
        
        Person person1 = new Person();
        person1.name = "aaaa";
        person1.age = 35;
        person1.display();
    }
}


class Person {
    String name;
    int age;

    void display() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
    void print(int a) {
    	System.out.println(a);
    	
    }
}

