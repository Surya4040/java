package Oops;

public class NestedClasses {
    // Outer class
    static class Outer {
        private String message = "Hello from the outer class.";

        // Inner class
        class Inner {
            void display() {
                System.out.println(message);
            }
        }
    }

    public static void main(String[] args) {
        Outer outer = new Outer();
        Outer.Inner inner = outer.new Inner();
        inner.display();
    }
}
