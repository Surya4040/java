package Oops;

public class Abstraction {
    // Abstract class
    static abstract class Animal {
        abstract void sound();

        void eat() {
            System.out.println("This animal eats food.");
        }
    }

    // Concrete class
    static class Dog extends Animal {
        @Override
        void sound() {
            System.out.println("The dog barks.");
        }
    }

    public static void main(String[] args) {
        Animal dog = new Dog();
        dog.sound();
        dog.eat();
    }
}
