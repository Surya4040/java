package Oops;

public class Encapsulation {
    static class Person {
        // Private fields
        private String name;
        private int age;

        // Public getter and setter methods
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }
    }

    public static void main(String[] args) {
        Person person = new Person();
        person.setName("Charlie");
        person.setAge(28);
        System.out.println("Name: " + person.getName());
        System.out.println("Age: " + person.getAge());
    }
}

