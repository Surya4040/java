package Oops.Packages;
public class Animal {
    protected void display() {
        System.out.println("This is an animal.");
    }
}
