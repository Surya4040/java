package Oops.Packages;

public class Util {
 public static void printMessage(String message) {
     System.out.println(message);
 }
}

