package JAVAOPERATORS;
public class RelationalOperators {
 public static void main(String[] args) {
     int x = 10;
     int y = 5;

     System.out.println("x == y: " + (x == y)); // Equal to
     System.out.println("x != y: " + (x != y)); // Not equal to
     System.out.println("x > y: " + (x > y));   // Greater than
     System.out.println("x < y: " + (x < y));   // Less than
     System.out.println("x >= y: " + (x >= y)); // Greater than or equal to
     System.out.println("x <= y: " + (x <= y)); // Less than or equal to
 }
}

