package JAVAOPERATORS;
public class ArithmeticOperators {
 public static void main(String[] args) {
     int a = 10;
     int b = 5;

     System.out.println("Addition: " + (a + b));        // Addition
     System.out.println("Subtraction: " + (a - b));     // Subtraction
     System.out.println("Multiplication: " + (a * b));  // Multiplication
     System.out.println("Division: " + (a / b));        // Division
     System.out.println("Modulus: " + (a % b));         // Modulus
 }
}
