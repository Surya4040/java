package JAVAOPERATORS;
public class UnaryOperators {
 public static void main(String[] args) {
     int x = 5;
     System.out.println("Initial value of x: " + x);

     x++; // Increment
     System.out.println("After x++: " + x);

     x--; // Decrement
     System.out.println("After x--: " + x);

     boolean isTrue = true;
     System.out.println("Initial value of isTrue: " + isTrue);
     System.out.println("After !isTrue: " + !isTrue); // Logical NOT

     int y = -x; // Unary minus
     System.out.println("Unary minus on x: " + y);
 }
}
