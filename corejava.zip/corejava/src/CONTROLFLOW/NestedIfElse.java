package CONTROLFLOW;
public class NestedIfElse {
 public static void main(String[] args) {
     int age = 25;
     int income = 30000;

     // Nested if-else statement
     if (age >= 18) {
         if (income >= 20000) {
             System.out.println("You are eligible for a credit card.");
         } else {
             System.out.println("Your income is too low for a credit card.");
         }
     } else {
         System.out.println("You are not old enough to apply for a credit card.");
     }
 }
}
