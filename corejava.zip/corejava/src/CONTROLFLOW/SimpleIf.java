package CONTROLFLOW;

//SimpleIf.java
public class SimpleIf {
 public static void main(String[] args) {
     int number = 10;

     // Simple if statement
     if (number > 5) {
         System.out.println("The number is greater than 5.");
     }

     System.out.println("This statement executes regardless of the condition.");
 }
}

