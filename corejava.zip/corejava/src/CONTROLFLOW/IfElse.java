package CONTROLFLOW;
public class IfElse {
 public static void main(String[] args) {
     int age = 18;

     // if-else statement
     if (age >= 18) {
         System.out.println("You are eligible to vote.");
     } else {
         System.out.println("You are not eligible to vote.");
     }
 }
}
