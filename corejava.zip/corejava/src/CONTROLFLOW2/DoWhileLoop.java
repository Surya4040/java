package CONTROLFLOW2;
public class DoWhileLoop {
 public static void main(String[] args) {
     int i = 1;
     do {
         System.out.println("Number: " + i);
         i++;
     } while (i <= 5);
 }
}

