package CONTROLFLOW2;
public class ForEachLoop {
 public static void main(String[] args) {
     // Array of numbers
     int[] numbers = {1, 2, 3, 4, 5};

     // Print each number in the array using a for-each loop
     for (int num : numbers) {
         System.out.println("Number: " + num);
     }
 }
}
