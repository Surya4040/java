package Array3;

public class MaxInEachRow {
    public static void main(String[] args) {
        int[][] matrix = {
            {3, 8, 1},
            {9, 4, 7},
            {6, 2, 5}
        };

        for (int i = 0; i < matrix.length; i++) {
            int max = matrix[i][0];
            for (int j = 1; j < matrix[i].length; j++) {
                if (matrix[i][j] > max) {
                    max = matrix[i][j];
                }
            }
            System.out.println("Max in row " + i + ": " + max);
        }
    }
}

