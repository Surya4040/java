package String1;

public class StringBuilders {
    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder("Hello");

        // Append (add to the end of the StringBuilder)
        sb.append(" World");
        System.out.println("After append: " + sb);

        // Insert (insert at a specific index)
        sb.insert(5, ",");
        System.out.println("After insert: " + sb);

        // Replace (replace a section of the string)
        sb.replace(0, 5, "Hi");
        System.out.println("After replace: " + sb);

        // Delete (delete a section of the string)
        sb.delete(2, 5);
        System.out.println("After delete: " + sb);

        // Reverse (reverse the characters in the StringBuilder)
        sb.reverse();
        System.out.println("After reverse: " + sb);

        // Length of StringBuilder
        System.out.println("Length: " + sb.length());

        // Capacity of StringBuilder
        System.out.println("Capacity: " + sb.capacity());
    }
}
