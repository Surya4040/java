package String1;

public class Strings {
    public static void main(String[] args) {
        String str = "Hello, World!";
        
        // Length of the string
        System.out.println("Length: " + str.length());

        // Character at a specific index
        System.out.println("Character at index 0: " + str.charAt(0));

        // Substring
        System.out.println("Substring (0,5): " + str.substring(0, 5));

        // Concatenation
        String newStr = str.concat(" Welcome to Java!");
        System.out.println("Concatenated String: " + newStr);

        // Uppercase and Lowercase
        System.out.println("Uppercase: " + str.toUpperCase());
        System.out.println("Lowercase: " + str.toLowerCase());

        // Replace characters
        System.out.println("Replace 'World' with 'Java': " + str.replace("World", "Java"));

        // Check if it contains a substring
        System.out.println("Contains 'Hello': " + str.contains("Hello"));
    }
}
