package Second;
public class Comments {
 public static void main(String[] args) {
     // This is a single-line comment

     /*
      * This is a multi-line comment
      * It can span multiple lines
      */

     /**
      * This is a documentation comment
      * It is generally used to describe the purpose of classes or methods
      */
     System.out.println("Comments in Java help to make code readable and understandable.");
 }
}
