package Second;

//TypeCasting.java
public class TypeCasting {
 public static void main(String[] args) {
     // Implicit Casting (smaller type to larger type, automatically done)
     int intNum = 100;
     double doubleNum = intNum; // int to double (automatic casting)

     System.out.println("Implicit Casting:");
     System.out.println("Integer: " + intNum);
     System.out.println("Converted to Double: " + doubleNum);

     // Explicit Casting (larger type to smaller type, manually done)
     double decimalNum = 9.78;
     int wholeNum = (int) decimalNum; // double to int (manual casting)

     System.out.println("\nExplicit Casting:");
     System.out.println("Double: " + decimalNum);
     System.out.println("Converted to Integer: " + wholeNum);

     // Example of casting char to int
     char letter = 'A';
     int letterAscii = (int) letter; // char to int (ASCII value)

     System.out.println("\nChar to Int Casting:");
     System.out.println("Character: " + letter);
     System.out.println("ASCII value: " + letterAscii);
 }
}
