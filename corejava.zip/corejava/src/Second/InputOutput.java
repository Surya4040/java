package Second;
import java.util.Scanner;
public class InputOutput {
 public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in); // Create a Scanner object for input

     // Output statement
     System.out.println("Enter your name: ");
     String name = scanner.nextLine(); 
     System.out.println("Enter your age: ");
     int age = scanner.nextInt(); 
     System.out.println("Hello, " + name + "! You are " + age + " years old.");
     scanner.close(); 
 }
}
