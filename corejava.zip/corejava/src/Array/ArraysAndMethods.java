package Array;

public class ArraysAndMethods {
    public static void main(String[] args) {
        int[] arun = {1, 2, 3, 4, 5};
        System.out.println("Arrays and Methods:");
        printArray(arun);
    }

    public static void printArray(int[] arrays) {
        for (int element : arrays) {
            System.out.println("element = " + element);
        }
    }
}
