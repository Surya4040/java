package Array;

import java.util.ArrayList;

public class ArrayListsExample {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        // Adding elements
        list.add("Apple");
        list.add("Banana");
        list.add("Cherry");

        System.out.println("Working with ArrayLists:");
        System.out.println("List: " + list);

        // Accessing elements
        System.out.println("First element: " + list.get(0));

        // Modifying elements
        list.set(1, "Blueberry");
        System.out.println("Modified list: " + list);

        // Removing elements
        list.remove(2);
        System.out.println("List after removal: " + list);

        // Iterating through the list
        System.out.println("Iterating through the list:");
        for (String element : list) {
            System.out.println("element = " + element);
        }
    }
}

