package Array;

public class DeclaringInitializingArrays {
    public static void main(String[] args) {
        // Declaring an array
        int[] array1;

        // Initializing an array
        array1 = new int[5];
        array1[0]=2;
        array1[1]=45;
        System.out.println(array1[0]);
        // Declaring and initializing an array
        int[] array2 = {1, 2, 3, 4, 5,};
System.out.println("array "+array2[3]);
        System.out.println("Declaring and Initializing Arrays:"+array2[4]);
        for (int i = 0; i < array2.length; i++) {
            System.out.println("array2[" + i + "] = " + array2[i]);
        }
    }
}

