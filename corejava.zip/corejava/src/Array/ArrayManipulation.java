package Array;

public class ArrayManipulation {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5};

        System.out.println("Array Manipulation:");

        // Accessing elements
        System.out.println("First element: " + array[0]);

        // Modifying elements
        array[2] = 10;
        System.out.println("Modified array:");
        for (int i = 0; i < array.length; i++) {
            System.out.println("array[" + i + "] = " + array[i]);
        }
    }
}

