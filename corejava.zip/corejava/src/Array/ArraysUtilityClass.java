package Array;

import java.util.Arrays;

public class ArraysUtilityClass {
    public static void main(String[] args) {
        int[] array = {5, 3, 2, 8, 1};

        // Sorting an array
        Arrays.sort(array);
        System.out.println("Sorted array: " + Arrays.toString(array));

        // Searching for an element
        int index = Arrays.binarySearch(array, 3);
        System.out.println("Element 3 found at index: " + index);

        // Filling an array
        int[] filledArray = new int[5];
        Arrays.fill(filledArray, 10);
        System.out.println("Filled array: " + Arrays.toString(filledArray));
        
    }
}

