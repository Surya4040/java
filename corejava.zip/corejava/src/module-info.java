/**
 * 
 */
/**
 * @author Admin
 *
 */
module corejava {
}