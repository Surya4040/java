package corejava;
public class DataTypes {
 public static void main(String[] args) {
     // Primitive Data Types
     byte byteVar = 10;
     short shortVar = 100;
     int intVar = 1000;
     long longVar = 10000L;
     float floatVar = 10.5f;
     double doubleVar = 20.99;
     char charVar = 'A';
     boolean boolVar = true;

     System.out.println("Byte Value: " + byteVar);
     System.out.println("Short Value: " + shortVar);
     System.out.println("Int Value: " + intVar);
     System.out.println("Long Value: " + longVar);
     System.out.println("Float Value: " + floatVar);
     System.out.println("Double Value: " + doubleVar);
     System.out.println("Char Value: " + charVar);
     System.out.println("Boolean Value: " + boolVar);

     // Non-Primitive Data Types
     String strVar = "Hello, Java!";
     int[] arrayVar = {1, 2, 3, 4, 5};

     System.out.println("String Value: " + strVar);
     System.out.print("Array Values: ");
     for (int num : arrayVar) {
         System.out.print(num + " ");
     }
 }
}
