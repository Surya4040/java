package corejava;
public class Keywords {
 public static void main(String[] args) {
     int number = 5; // 'int' is a keyword
     boolean isJavaFun = true; // 'boolean' is a keyword
     double pi = 3.14159; // 'double' is a keyword
     System.out.println("Java Keywords: public, class, static, void, int, boolean, double, and many more.");
 }
}
