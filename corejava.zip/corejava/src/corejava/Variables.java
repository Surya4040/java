package corejava;

public class Variables {
 int instanceVar = 10; // Instance variable

 static int staticVar = 20; // Static variable

 public void localVariableExample() {
     int localVar = 30; // Local variable
     System.out.println("Local variable: " + localVar);
 }

 public static void main(String[] args) {
     Variables example = new Variables();
     System.out.println("Instance variable: " + example.instanceVar);
     System.out.println("Static variable: " + Variables.staticVar);
     
     example.localVariableExample();
 }
}

