package corejava;
public class Identifiers {
 public static void main(String[] args) {
     int age = 25; // 'age' is an identifier for an integer variable
     String firstName = "John"; // 'firstName' is an identifier for a String variable
     double salary = 50000.00; // 'salary' is another identifier

     System.out.println("Identifiers in Java: age, firstName, salary.");
 }
}

