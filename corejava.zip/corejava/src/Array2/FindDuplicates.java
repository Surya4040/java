package Array2;

import java.util.HashSet;

public class FindDuplicates {
    public static void main(String[] args) {
        int[] array = {2, 4, 3, 5, 3, 2, 6};

        HashSet<Integer> seen = new HashSet<>();
        System.out.println("Duplicate elements:");

        for (int num : array) {
            if (!seen.add(num)) {  // If add() returns false, num is a duplicate
                System.out.println(num);
            }
        }
    }
}
