package Array2;

public class RotateArray {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5};
        int k = 2;

        int length = array.length;
        int[] rotated = new int[length];

        for (int i = 0; i < length; i++) {
            rotated[(i + k) % length] = array[i];
        }

        System.out.println("Array after rotation:");
        for (int num : rotated) {
            System.out.print(num + " ");
        }
    }
}
