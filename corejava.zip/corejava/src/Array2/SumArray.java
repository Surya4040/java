package Array2;

public class SumArray {
    public static void main(String[] args) {
        int[] array = {3, 5, 2, 8, 7};
        int sum = 0;

        for (int num : array) {
            sum += num;
        }

        System.out.println("Sum of elements: " + sum);
    }
}
