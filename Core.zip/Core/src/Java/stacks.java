package Java;
import java.util.Stack;
public class stacks {
	 public static void main(String[] args) {
	        Stack<String> stack = new Stack<>();

	        stack.push("Element 1");
	        stack.push("Element 2");
	        stack.push("Element 3");

	        String poppedElement = stack.pop();
	        System.out.println("Popped Element: " + poppedElement);

	        String topElement = stack.peek();
	        System.out.println("Top Element: " + topElement);

	        boolean isEmpty = stack.isEmpty();
	        System.out.println("Is Stack Empty? " + isEmpty);

	        int size = stack.size();
	        System.out.println("Stack Size: " + size);
	    }
}
