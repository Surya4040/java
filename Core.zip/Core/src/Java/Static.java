package Java;

public class Static {
	
	    // Static method
	     static  void staticMethod() {
	        System.out.println("Static method");
	    }

	    public static void main(String[] args) {
	        // Call the static method using the class name
	    	
	        staticMethod();
	    }
	}


