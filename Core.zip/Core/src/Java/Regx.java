package Java;


	import java.util.regex.Matcher;
	import java.util.regex.Pattern;
	import java.util.Scanner;
	public class Regx {
		    public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);
		        System.out.print("Enter an email address: ");
		        String userInput = scanner.nextLine();
		        String emailPattern = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
		        Pattern pattern = Pattern.compile(emailPattern);
		        Matcher matcher = pattern.matcher(userInput);
		        if (matcher.matches()) {
		            System.out.println("Valid email address: " + userInput);
		        } else {
		            System.out.println("Invalid email address: " + userInput);
		         
		        }
		        scanner.close();
		    }
		}

	