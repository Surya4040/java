package Java;

public class operator {
public static void main(String[]args) {
int k=30;
int l=20;
boolean m=k<=l | k==30;
System.out.println(m);
System.out.println(k);
	
	
	//operator
	/*
	 Arithmetic Operators:

+ (Addition)
- (Subtraction)
* (Multiplication)
/ (Division)
% (Modulus)
Relational Operators:

== (Equal to)
!= (Not equal to)
> (Greater than)
< (Less than)
>= (Greater than or equal to)
<= (Less than or equal to)

Logical Operators:

&& (Logical AND)
|| (Logical OR)
! (Logical NOT)

Bitwise Operators:

& (Bitwise AND)
| (Bitwise OR)
^ (Bitwise XOR)
~ (Bitwise Complement)
<< (Left shift)
>> (Right shift)
>>> (Unsigned right shift)

Assignment Operators:

= (Simple assignment)
+= (Add and assign)
-= (Subtract and assign)
*= (Multiply and assign)
/= (Divide and assign)
%= (Modulus and assign)
&= (Bitwise AND and assign)
|= (Bitwise OR and assign)
^= (Bitwise XOR and assign)
<<= (Left shift and assign)
>>= (Right shift and assign)
>>>= (Unsigned right shift and assign)

Increment and Decrement Operators:

++ (Increment by 1)
-- (Decrement by 1)
Conditional Operator (Ternary Operator):

? : (Conditional operator)
String result = (number % 2 == 0) ? "Even" : "Odd";
 System.out.println("The number is " + result);

Instanceof Operator:

instanceof (Checks whether an object is an instance of a particular class or interface)
	 */
	double math= Math.random()*10000;
	
	System.out.println(math);
	System.out.println();
	String str="asdfhjkllkjhgf";
	System.out.println("this is string "+str);
	
	int number=31;
	int result=(number <=10) ? 1:2;
	System.out.println(result);
	String res = (number % 2 == 0) ? "Even" : "Odd";
	 System.out.println("The number is " + res);
	
int a=10;

System.out.println("a= "+ a++);
System.out.println("a= "+ a);
 a*=100;
int b=3;
int c=a*b;
System.out.println(a);
if(a!=b && a<=6) {
	System.out.println("True");
}
	a=++a;
	System.out.println(a);
	for(int i=0;i<=10;++i) {
		System.out.println(i);
	}
}
}
