package Java;


	// Compile-time polymorphism (Method Overloading)
	class MathOperations {
	    public int add(int a, int b) {
	        return a + b;
	    }

	    public double add(double a, double b) {
	        return a + b;
	    }
	}

	// Runtime polymorphism (Method Overriding)
	class Animal {
	    public void makeSound() {
	        System.out.println("Some generic sound");
	    }
	}

	class Dog extends Animal {
	   
	    public void makeSound() {
	        System.out.println("dog sound");
	    }
	}

	class Cat extends Animal {
	  
	    public void makeSound() {
	        System.out.println("cat voice!");
	    }
	}
	

	public class polimorphism {
	    public static void main(String[] args) {
	        // Compile-time polymorphism (Method Overloading)
	        MathOperations math = new MathOperations();
	        System.out.println(math.add(5, 10));
	        System.out.println(math.add(3.5, 7.2));

	        // Runtime polymorphism (Method Overriding)
	        Animal dog = new Dog();
	        Animal cat = new Cat();

	        dog.makeSound(); 
	        cat.makeSound(); 
	    }
	}

