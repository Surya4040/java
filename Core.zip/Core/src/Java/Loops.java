package Java;

public class Loops {

	public static void main(String[] args) {
	int i = 0;
	
	/*while(i<5) {
		
	//	i++;
		//System.out.println(i);
		
	//}
		while (i < 5) {
		
			if(i>=3) {
		    System.out.println("surya");
			}else {
				System.out.println(i);
			}
		    ++i;
		    
		}

		
		int j = 0;
		do {
		    System.out.println(j);
		    j++;
		} while (j > 5);

		
		for (int k = 0; k < 5; ++k) {
		    System.out.println(k);
		    for(int l=0;l<k;l++) {
		    	System.out.print("surya");
		    }
		    System.out.println(" ");
		}

		
		
		//int[] numbers = {1, 2, 3, 4, 5};
	//	for (int num : numbers) {
		   // System.out.println(num);
		//}
*/
		
		
		
		for (int l = 0; l < 10; l++) {
		    if (l == 6) {
		        break; // exit the loop when i is 5
		    }
		    if (l % 2 == 0) {
		        continue; // skip even numbers
		    }
		    System.out.println(l);
		}

	}

}
