package Java;

public class Class {

}
