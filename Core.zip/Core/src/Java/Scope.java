package Java;

public class Scope {

	    // Class scope variable
	    private static int Variable = 100;

	    public static void main(String[] args) {
	        // Method scope variable
	        int methodScopeVariable = 50;
	        
	        System.out.println("Class Scope Variable: " + Variable);
	        System.out.println("Method Scope Variable: " + methodScopeVariable);

	        if (true) {
	            // Block scope variable
	            int blockScopeVariable = 25;
	            System.out.println("Block Scope Variable: " + blockScopeVariable);
	        }
	       

	        // Cannot access blockScopeVariable here

	        // Invoking a method with its own scope
	        myMethod(8);
	    }

	    // Another method with its own scope
	    private static void myMethod(int parameter) {
	        // Parameter and local variable have method scope
	        int localVar = 10;

	        System.out.println("Method Parameter: " + parameter);
	        System.out.println("Method Local Variable: " + localVar);


	        // Accessing class scope variable
	        System.out.println("Class Scope Variable from Method: " + Variable);
	    }
	}

