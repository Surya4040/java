package Java;

public class ForEach {
	
	    public static void main(String[] args) {
	        // Example with an array
	        int[] numbers = {1, 2, 3, 4, 5};

	        System.out.println("Iterating over an array:");
	        for (int number : numbers) {
	            System.out.print(number + " ");
	        }
	        System.out.println();
	    }
	}


