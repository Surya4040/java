package Java;

	class Car {
	    String make;
	    String model;
	    int year;
	    
	    public Car(String make, String model, int year) {
	        this.make = make;
	        this.model = model;
	        this.year = year;
	    }

	    
	    public void displayInfo() {
	        System.out.println("Make: " + make);
	        System.out.println("Model: " + model);
	        System.out.println("Year: " + year);
	    }
	}
	class two{
		public  void bike() {
			System.out.println("this is a bike");
		}
	}

	public class Object {
	    public static void main(String[] args) {

	        Car myCar = new Car("Toyota", "Camry", 2022);
            two bike=new two();
            bike.bike();
	        
	        System.out.println("Before modification:");
	        myCar.displayInfo();
	        myCar.year = 2023;
	        System.out.println("\nAfter modification:");
	        myCar.displayInfo();
	    }
	}

