package Java;
public class Basic {
public static void main(String[]args) {
	
	System.out.println("HELLO");

	
	int a=25;
	
if(a==25) {
	System.out.println("if value");
	if(a>=100) {
		System.out.println("nestred value");
	}else {
	 if(a==25) {
			System.out.println("if in else place");
		}
		System.out.println("else value");
	}
}
	 a=100;
	 a+=5;
	int b=102;
	int sum=a + b;
	System.out.println("sum= "+sum);
	int num=100;
	int numb=100;
	int ch=num & 6 ;
	System.out.println("bit wise"+ch);
	int c=10;
	 c*=20;
	 System.out.println(c);
	if(!(a>10&&a>=101)) {
		System.out.println("its true");
	}
	
System.out.println(sum);
int d=10;
System.out.println(++d);
System.out.println(d);
int number=101;
String result = (number % 2 == 0) ? "Even" : "Odd";
System.out.println("The number is " + result);
for(int i=0;i<50;i++) {
	System.out.println("Surya");
}
}
}
