package Java;

public class try1 {
public static void main(String[]args) {
	System.out.println("hello");
}
}
