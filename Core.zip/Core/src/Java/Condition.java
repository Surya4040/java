package Java;

public class Condition {
public static void main(String[]args) {
	int number = 10;

	if (number < 100) {
		if(number==10) {
			if(number==10) {
				
			}
			System.out.println("Nestred if");
		}
	    System.out.println("The number is positive.");
	}

// if else
	/*
  number = 5;

if (number > 0) {
    System.out.println("The number is positive.");
} else {
    System.out.println("The number is non-positive.");
}


*/
 number = -5;

if (number == 7 && number<=7) {
    System.out.println("The number is positive.");
} else if (number != 0) {
    System.out.println("The number is negative.");
} 
else if (number == 0) {
    System.out.println("equal to 0.");
} 

else {
    System.out.println("The number is zero.");
}

/*
 number = 0;

if (number > 0) {
    System.out.println("The number is positive.");
} else if (number < 0) {
    System.out.println("The number is negative.");
} else {
    System.out.println("The number is zero.");
}


 */
}
}
