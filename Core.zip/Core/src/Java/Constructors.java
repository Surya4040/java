package Java;

	class Person {
	    String name;
	    int age;

	    Person() {
	        System.out.println("Default Constructor");
	    }

	    Person(String n, int a) {
	        name = n;
	        age = a;
	    }

	    Person(Person original) {
	        name = original.name;
	        age = original.age;
	    }

	    void displayInfo() {
	        System.out.println("Name: " + name + ", Age: " + age);
	    }
	}

	public class Constructors {
	    public static void main(String[] args) {
	        Person person1 = new Person();
	        person1.displayInfo();

	        Person person2 = new Person("John", 25);
	        person2.displayInfo();

	        Person person3 = new Person(person2);
	        person3.displayInfo();
	    }
	}

