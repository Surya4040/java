package Java;
public class Array {
	static int a=10;
	
    public static void main(String[] args) {
    	System.out.println(a++);
    	System.out.println(a);
    	
//basic
    	int b=5;
        int[] numbers = {1, 2, 3, 49, 588};
        System.out.println("Print single value: "+numbers[4]);
        System.out.println("Elements of the array:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.println(numbers[i]+" ");
        }

//sum a array
        int sum = 0;
        for (int i = 0; i < numbers.length; i++) {
            sum += numbers[i];
            
        }
        System.out.println("Sum of the array elements: " + sum);
        
        
//String in array
        String[] names = {"one", "two", "three", "four"};
        System.out.println("Names in the array:"+names[1]);
        for (int i = 0; i < names.length; i++) {
            System.out.println(names[i]);
        }
    }
}
