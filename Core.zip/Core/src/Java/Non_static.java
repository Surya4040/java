package Java;

public class Non_static {
	    // Non-static method
	    public void nonStaticMethod() {
	        System.out.println("Non-static method");
	    }

	    public static void main(String[] args) {
	        // Create an object of the class
	       Non_static myObject = new Non_static();

	        // Call the non-static method using the object
	       System.out.println("first print");
	        myObject.nonStaticMethod();
	    }
	}


