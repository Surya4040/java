package Java;

public class Parameter {
	    public static int addNumbers(int num1, int num2) {
	        return num1 + num2;
	    }
	    public static void printGreeting(String name) {
	        System.out.println("Hello, " + name + "!");
	    }
	    public static int getRandomNumber() {
	    	
	        return (int) (Math.random() * 10000);
	    }
	    public static void printMessage() {
	        System.out.println("This is a message.");
	    }

	    public static void main(String[] args) {
	        int sum = addNumbers(5, 7);
	        System.out.println("Sum: " + sum);
	        printGreeting("John");
	        int random = getRandomNumber();
	        System.out.println("Random Number: " + random);
	        printMessage();
	    }
	}

