package Java;

public class variable {
public static void main (String[]args) {
	//variable
	int a=10;
	int b=20;
	System.out.println(a*b);
	int c,d,e;
	c=10;
	d=20;
	e=(c+d)*6;
	System.out.println(e);
	//data type
	/*
	Primitive Data Types:
byte:

Size: 8 bits
Range: -128 to 127

short:
Size: 16 bits
Range: -32,768 to 32,767

int:
Size: 32 bits
Range: -2^31 to 2^31-1
long:

Size: 64 bits
Range: -2^63 to 2^63-1
float:

Size: 32 bits
Example: 3.14f
double:

Size: 64 bits
Example: 3.14
char:

Size: 16 bits
Represents a single character (e.g., 'A', '5', '@')
boolean:
Represents true or false values only


Reference Data Types:
Classes:

User-defined data types created using the class keyword.
Interfaces:

Similar to classes but used for achieving abstraction and multiple inheritance.
Arrays:
Collections of similar data types.
Enumerations (Enums):
A special data type that enables for a variable to be a set of predefined constants.
Strings:
A sequence of characters. In Java, strings are objects.


Widening Casting (automatically) - converting a smaller type to a larger type size
byte -> short -> char -> int -> long -> float -> double

Narrowing Casting (manually) - converting a larger type to a smaller size type
double -> float -> long -> int -> char -> short -> byte
	*/
	
	int num=10;
	float numb=num;
	System.out.println(numb);
	
	int number=(int)numb;
	System.out.println(number);
}
}
