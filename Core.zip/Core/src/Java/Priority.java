package Java;
import java.util.PriorityQueue;
public class Priority {
	    public static void main(String[] args) {
	        PriorityQueue<String> priorityQueue = new PriorityQueue<>();
	        priorityQueue.offer("a");
	        priorityQueue.offer("z");
	        priorityQueue.offer("a");
	        priorityQueue.offer("d");
	        while (!priorityQueue.isEmpty()) {
	            String element = priorityQueue.poll();
	            System.out.println("Polled Element: " + element);
	            
	        }
	    }
	}




