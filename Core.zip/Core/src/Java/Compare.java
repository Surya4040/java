package Java;

public class Compare {
	    public static void main(String[] args) {
	        // Two string variables
	        String str1 = "Hello";
	        String str2 = "Hello";

	        // Comparing the strings using equals method
	        if (str1.equals(str2)) {
	            System.out.println("The strings are equal.");
	        } else {
	            System.out.println("The strings are not equal.");
	        }
	    }
	}


