package Java;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
	import java.io.*;

	public class File {
	    public static void main(String[] args) {
	        // Writing to a file
	    	  try (BufferedWriter writer = new BufferedWriter(new FileWriter("java.txt"))) {
		            writer.write("Hello, this is a file handling example in Java.");
		            writer.write("java fullstack");
		        } catch (Exception e) {
		            e.printStackTrace();
		        }finally {
		        	System.out.println("this is myfinally");
		        }

	        // Reading from a file
	        try (BufferedReader reader = new BufferedReader(new FileReader("JAVA internship.docx"))) {
	            String line;
	            System.out.println("Contents of the file:");
	            while ((line = reader.readLine()) != null) {
	                System.out.println(line);
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}

