package Java;
public class Method {
	  public static void main(String[] args) {
	        // Call the displayMessage method
	        displayMessage();
	        displayMessage();
	       
System.out.println("print");
	        // Call the sumNumbers method and store the result in a variable
sumNumbers(6,8);
	        int result = sumNumbers(5, 7);
	        int result1 = sumNumbers(8, 55);
	       
	        System.out.println("Sum of numbers: " +  sumNumbers(6, 9));
	        // Display the result
	        System.out.println("Sum of numbers: " + result);
	        System.out.println("Sum of numbers: " + result1);
	    }

	    // Method to display a simple message
	    public static void displayMessage() {
	        System.out.println("Hello from the displayMessage method!");
	        System.out.println("second time print");
	        int a=10;
	        int b=30;
	        System.out.println(a*b);
	    }

	    // Method to calculate the sum of two numbers
	    public static int sumNumbers(int a, int b) {
	    	
	        return a * b;
	    }

	    
}
