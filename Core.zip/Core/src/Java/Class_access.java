package Java;

public class Class_access {
	

	    public static void main(String[] args) {
	        OuterClass outerObject = new OuterClass();
	        outerObject.accessPrivateClass();
	    }
	}

	 class OuterClass {

	    // Private inner class
	    private class PrivateInnerClass {
	        public void innerMethod() {
	            System.out.println("Method in PrivateInnerClass");
	        }
	    }

	    public void accessPrivateClass() {
	        PrivateInnerClass innerObject = new PrivateInnerClass();
	        innerObject.innerMethod();
	    }
	}

