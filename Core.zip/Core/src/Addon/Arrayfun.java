package Addon;
import java.util.Arrays;
public class Arrayfun {
	    public static void main(String[] args) {
	        String[] names = {"rohit","surya", "sachin" ,"ishan",  "David"};
	        System.out.println("Array to String: " + Arrays.toString(names));
	        
	        Arrays.sort(names);
	        System.out.println("Sorted Array: " + Arrays.toString(names));
	        
	        String key = "David";
	        int index = Arrays.binarySearch(names, key);
	        System.out.println("Index of " + key + ": " + index);
	        
	        String[] filledArray = new String[10];
	        Arrays.fill(filledArray, "Default");
	        System.out.println("Filled Array: " + Arrays.toString(filledArray));
	        
	        String[] originalArray = {"One", "Two", "Three", "Four", "Five"};
	        String[] copiedArray = Arrays.copyOf(originalArray, 2);
	        System.out.println("Copied Array: " + Arrays.toString(copiedArray));
	        
	        String[] array1 = {"Apple", "Banana", "Orange"};
	        String[] array2 = {"Apple", "Banana", "Orange"};
	        boolean areEqual = Arrays.equals(array1, array2);
	        System.out.println("Arrays are equal: " + areEqual);
	    }
	}


