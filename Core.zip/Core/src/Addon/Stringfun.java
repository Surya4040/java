package Addon;

import java.util.Arrays;

public class Stringfun {
    public static void main(String[] args) {
        String str = "Hello, World!";
        int length = str.length();
        
        char charAtIndex = str.charAt(7);
        
        String substring1 = str.substring(4);
        
        String substring2 = str.substring(0, 5);
        
        int indexOfWorld = str.indexOf("World");
        
        int lastIndexOfl = str.lastIndexOf("l");
        
        boolean startsWithHello = str.startsWith("Hello");
        
        boolean endsWithWorld = str.endsWith("World!");
        
        String upperCaseStr = str.toUpperCase();
        String lowerCaseStr = str.toLowerCase();
        
        String stringWithSpaces = "   Trim me!   ";
        String trimmedString = stringWithSpaces.trim();
        
        String replacedString = str.replace('o', 'S');
        
        String replacedHello = str.replace("Hello", "Greetings");
        
        String greeting = "Hello";
        String name = "John";
        
        String csvData = "John,Doe,30";
        String[] data = csvData.split(" ");
        String message = greeting.concat(", ").concat(name);
        String messageWithPlusOperator = greeting + ", " + name;

        System.out.println("Length: " + length);
        System.out.println("Character at Index 7: " + charAtIndex);
        System.out.println("Substring from Index 7: " + substring1);
        System.out.println("Substring from Index 0 to 4: " + substring2);
        System.out.println("Index of 'World': " + indexOfWorld);
        System.out.println("Last Index of 'l': " + lastIndexOfl);
        System.out.println("Starts with 'Hello': " + startsWithHello);
        System.out.println("Ends with 'World!': " + endsWithWorld);
        System.out.println("Uppercase: " + upperCaseStr);
        System.out.println("Lowercase: " + lowerCaseStr);
        System.out.println("Trimmed String: " + trimmedString);
        System.out.println("Replaced 'o' with '0': " + replacedString);
        System.out.println("Replaced 'Hello' with 'Greetings': " + replacedHello);
        System.out.println("Concatenation: " + message);
        System.out.println("Concatenation with + operator: " + messageWithPlusOperator);
        System.out.println("Split String: " + Arrays.toString(data));
    }
}

