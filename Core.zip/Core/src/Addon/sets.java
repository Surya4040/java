package Addon;


	import java.util.HashSet;
	import java.util.LinkedHashSet;
	import java.util.TreeSet;
	import java.util.Set;
	public class sets {
	    public static void main(String[] args) {
	        Set<String> hashSet = new HashSet<>();
	        hashSet.add("Apple");
	        hashSet.add("Banana");
	        hashSet.add("Orange");
	        System.out.println("HashSet: " + hashSet);
	        Set<String> linkedHashSet = new LinkedHashSet<>();
	        linkedHashSet.add("Apple");
	        linkedHashSet.add("Banana");
	        linkedHashSet.add("Orange");
	        System.out.println("LinkedHashSet: " + linkedHashSet);
	        Set<String> treeSet = new TreeSet<>();
	        treeSet.add("Apple");
	        treeSet.add("Banana");
	        treeSet.add("Orange");
	        System.out.println("TreeSet: " + treeSet);
	    }
	}


