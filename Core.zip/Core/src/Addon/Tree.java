package Addon;
	import java.util.Map;
	import java.util.TreeMap;
	public class Tree {
	    public static void main(String[] args) {
	        TreeMap<String, Integer> treeMap = new TreeMap<>();
	        treeMap.put("sharma", 25);
	        treeMap.put("surya", 30);
	        treeMap.put("sachin", 28);
	        System.out.println("Age of sharma: " + treeMap.get("sharma"));
	        for (Map.Entry<String, Integer> entry : treeMap.entrySet()) {
	            System.out.println(entry.getKey() + ": " + entry.getValue());
	        }
	        String keyToCheck = "surya";
	        if (treeMap.containsKey(keyToCheck)) {
	            System.out.println(keyToCheck + " exists in the TreeMap.");
	        }
	        String keyToRemove = "sachin";
	        treeMap.remove(keyToRemove);
	        System.out.println(keyToRemove + " removed from the TreeMap.");

	        System.out.println("Size of the TreeMap: " + treeMap.size());
	    }
	}

