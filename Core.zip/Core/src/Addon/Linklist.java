package Addon;


	import java.util.LinkedList;

	public class Linklist {
	    public static void main(String[] args) {
	        LinkedList<String> linkedList = new LinkedList<>();
	        linkedList.add("Apple");
	        linkedList.add("Banana");
	        linkedList.add("Orange");
	        linkedList.add("Grapes");
	        System.out.println("Linked List: " + linkedList);
	        linkedList.addFirst("Mango");
	        linkedList.addLast("Cherry");
	        System.out.println("Modified Linked List: " + linkedList);
	        System.out.println("First Element: " + linkedList.getFirst());
	        System.out.println("Last Element: " + linkedList.getLast());
	        linkedList.remove("Banana");
	        System.out.println("Linked List after removal: " + linkedList);
	        if (linkedList.contains("Grapes")) {
	            System.out.println("Grapes are present in the linked list.");
	        }
	        System.out.println("Size of the Linked List: " + linkedList.size());
	        linkedList.clear();
	        if (linkedList.isEmpty()) {
	            System.out.println("The linked list is empty.");
	        }
	    }
	}


