package Addon;


	import java.util.HashMap;
	import java.util.Map;
	public class Hash {
	    public static void main(String[] args) {
	        Map<String, Integer> hashMap = new HashMap<>();
	        hashMap.put("rohit", 25);
	        hashMap.put("surya", 30);
	        hashMap.put("sachin", 28);
	        System.out.println("Age of rohit: " + hashMap.get("rohit"));
	        for (Map.Entry<String, Integer> entry : hashMap.entrySet()) {
	            System.out.println(entry.getKey() + ": " + entry.getValue());
	        }

	        String keyToCheck = "surya";
	        if (hashMap.containsKey(keyToCheck)) {
	            System.out.println(keyToCheck + " exists in the map.");
	        }
	        String keyToRemove = "sachin";
	        hashMap.remove(keyToRemove);
	        System.out.println(keyToRemove + " removed from the map.");
	        System.out.println("Size of the map: " + hashMap.size());
	    }
	}

