package Addon;


	import java.util.ArrayList;

	public class Arrlist {
	    public static void main(String[] args) {
	        ArrayList<String> fruits = new ArrayList<>();
	        fruits.add("Apple");
	        fruits.add("Banana");
	        fruits.add("Orange");
	        fruits.add("Mango");
	        System.out.println("Fruits: " + fruits);
	        System.out.println("Iterating through the ArrayList:");
	        for (String fruit : fruits) {
	            System.out.println(fruit);
	        }

	        fruits.add(1, "Grapes");
	        System.out.println("Fruits: " + fruits);
	        fruits.remove("Banana");
	        System.out.println("Fruits: " + fruits);
	        fruits.set(1, "Pineapple");
	        System.out.println("Fruits: " + fruits);
	        if (fruits.contains("Mango")) {
	            System.out.println("Mango is present in the ArrayList.");
	        }
	        System.out.println("Size of the ArrayList: " + fruits.size());
	        fruits.clear();
	        if (fruits.isEmpty()) {
	            System.out.println("The ArrayList is empty.");
	        }
	    }
	}

