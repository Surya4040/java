/**
 * 
 */
/**
 * @author Admin
 *
 */
module Core {
}