package OOPS;

class caps {
    private String name;
    private int age;

    public caps(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age >= 0) {
            this.age = age;
        } else {
            System.out.println("Invalid age value.");
        }
    }
}


public class Encapsulation {
    public static void main(String[] args) {
        caps person = new caps("sachin", 45);

        System.out.println("Original Name: " + person.getName());
        System.out.println("Original Age: " + person.getAge());

        person.setName("Rohit");
        person.setAge(36);

        System.out.println("Updated Name: " + person.getName());
        System.out.println("Updated Age: " + person.getAge());
    }
}

