package OOPS;


	class Vehicle {
	    void start() {
	        System.out.println("Vehicle is starting.");
	    }

	    void stop() {
	        System.out.println("Vehicle is stopping.");
	    }
	}

	class Car extends Vehicle {
	    void drive() {
	        System.out.println("Car is driving.");
	    }
	}

	class SportsCar extends Car {
	    void turboBoost() {
	        System.out.println("SportsCar is boosting with turbo.");
	    }
	}

	public class Multilevel_inheritance {
	    public static void main(String[] args) {
	        SportsCar mySportsCar = new SportsCar();

	        mySportsCar.start();
	        mySportsCar.stop();

	        mySportsCar.drive();

	        mySportsCar.turboBoost();
	    }
	}

