package OOPS;

	interface Engine {
	    void start();
	    void stop();
	}

	interface MusicPlayer {
	    void playMusic();
	}

	class bike implements Engine, MusicPlayer {
	    public void start() {
	        System.out.println("bike engine is starting.");
	    }

	    public void stop() {
	        System.out.println("bike engine is stopping.");
	    }

	    public void playMusic() {
	        System.out.println("music is playing.");
	    }

	    void drive() {
	        System.out.println("bike is driving.");
	    }
	}

	public class Interface {
	    public static void main(String[] args) {
	        bike myCar = new bike();

	        myCar.start();
	        myCar.stop();
	        myCar.playMusic();
	        myCar.drive();
	    }
	}

