package OOPS;

	abstract class Shape {
	    abstract void draw();

	    void color() {
	        System.out.println("Applying color to the shape.");
	    }
	}

	class Circle extends Shape {
	    void draw() {
	        System.out.println("Drawing a circle.");
	    }
	}

	class Rectangle extends Shape {
	    void draw() {
	        System.out.println("Drawing a rectangle.");
	    }
	}

	public class Abstraction {
	    public static void main(String[] args) {
	        Circle circle = new Circle();
	        Rectangle rectangle = new Rectangle();

	        circle.draw();
	        circle.color();

	        rectangle.draw();
	        rectangle.color();
	    }
	}

