package OOPS;

	class VehicleEngine {
	    void start() {
	        System.out.println("Engine is starting.");
	    }

	    void stop() {
	        System.out.println("Engine is stopping.");
	    }
	}

	class SoundSystem  {
	    void playMusic() {
	        System.out.println("Music is playing.");
	    }
	}
	class demo extends SoundSystem{
		void demo() {
			System.out.println("demo");
		}
	}
	
	class LuxuryCar extends VehicleEngine {
	    void drive() {
	        System.out.println("Luxury car is driving.");
	    }
	}

	class MountainBike extends VehicleEngine {
	    void pedal() {
	        System.out.println("Mountain bike is pedaling.");
	    }
	}

	class ElectricCar extends VehicleEngine {
	    void drive() {
	        System.out.println("Electric car is driving.");
	    }

	    void chargeBattery() {
	        System.out.println("Battery is charging.");
	    }
	}

	public class Hybrid_inheritance {
	    public static void main(String[] args) {
	        LuxuryCar myLuxuryCar = new LuxuryCar();
	        MountainBike myMountainBike = new MountainBike();
	        ElectricCar myElectricCar = new ElectricCar();
	        demo demo=new demo();
	        demo.playMusic();
	        myLuxuryCar.start();
	        myLuxuryCar.stop();
	        myMountainBike.start();
	        myMountainBike.stop();
	        myElectricCar.start();
	        myElectricCar.stop();
	        myLuxuryCar.drive();
	        myMountainBike.pedal();
	        myElectricCar.drive();
	        myElectricCar.chargeBattery();
	    }
	}

