package OOPS;




// Compile-time polymorphism (Method Overloading)
class MathOperations {
    public int add(int a, int b) {
        return a + b;
    }
    

    public double add(double a, double b) {
        return a + b;
    }
}

// Runtime polymorphism (Method Overriding)
class Animals {
    public void makeSound() {
        System.out.println("Some generic sound");
    }
}

class Dogs extends Animals {
   
    public void makeSound() {
        System.out.println("dog sound");
    }
}

class Cat extends Animals {
  
    public void makeSound() {
        System.out.println("cat voice!");
    }
}


public class Polimorphism {
    public static void main(String[] args) {
        // Compile-time polymorphism (Method Overloading)
        MathOperations math = new MathOperations();
        System.out.println(math.add(5, 10));
        System.out.println(math.add(3.5, 7.2));

        // Runtime polymorphism (Method Overriding)
        Dogs dog=new Dogs();
        Animals animal = new Animals();
        Animals cat = new Cat();
        
        dog.makeSound();
        animal.makeSound(); 
        cat.makeSound(); 
    }
}

