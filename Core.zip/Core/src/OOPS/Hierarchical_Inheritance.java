package OOPS;

	class Vehicles {
	    void start() {
	        System.out.println("Vehicle is starting.");
	    }

	    void stop() {
	        System.out.println("Vehicle is stopping.");
	    }
	}

	class Cars extends Vehicles {
	    void drive() {
	        System.out.println("Car is driving.");
	    }
	}

	class Motorbike extends Vehicles {
	    void ride() {
	        System.out.println("Motorbike is riding.");
	    }
	}

	class Bicycle extends Vehicles {
	    void pedal() {
	        System.out.println("Bicycle is pedaling.");
	    }
	}

	public class Hierarchical_Inheritance {
	    public static void main(String[] args) {
	        Cars myCar = new Cars();
	        Motorbike myMotorbike = new Motorbike();
	        Bicycle myBicycle = new Bicycle();

	        myCar.start();
	        myCar.stop();
	        myCar.drive();
	        myMotorbike.start();
	        myMotorbike.stop();

	        myBicycle.start();
	        myBicycle.stop();

	        
	        myMotorbike.ride();
	        myBicycle.pedal();
	    }
	}

