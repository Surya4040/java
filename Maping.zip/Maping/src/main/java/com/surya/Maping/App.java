package com.surya.Maping;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class App {
    public static void main(String[] args) {
        // create a configuration object
        Configuration configuration = new Configuration().configure();

        // create a session factory
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        // create a session
        Session session = sessionFactory.openSession();

        // start a transaction
        session.beginTransaction();

        // create a teacher
        Teacher teacher = new Teacher();
        teacher.setName("Mr. Smith");

        // create three students
        Student student1 = new Student();
        student1.setName("Alice");
        student1.setTeacher(teacher);

        Student student2 = new Student();
        student2.setName("Bob");
        student2.setTeacher(teacher);

        Student student3 = new Student();
        student3.setName("Charlie");
        student3.setTeacher(teacher);

        // add the students to the teacher's list of students
       
        teacher.getStudents().add(student2);
        teacher.getStudents().add(student3);

        // save the teacher and students
        session.save(teacher);
        session.save(student1);
        session.save(student2);
        session.save(student3);

        // commit the transaction
        session.getTransaction().commit();

        // retrieve all teachers from the database
        List<Teacher> teachers = session.createQuery("FROM Teacher").list();

        // print the teachers
        for (Teacher t : teachers) {
            System.out.println("Teacher: " + t.getName());
            System.out.println("Students:");
            for (Student s : t.getStudents()) {
                System.out.println("\t" + s.getName());
            }
        }

        // close the session
        session.close();

        // close the session factory
        sessionFactory.close();
    }
}  